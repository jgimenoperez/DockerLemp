import {getBreakfast} from './foo';
import {letters} from './foo';

import {getBreakfast, getLunch} from './foo';
import dinnerTime, {baz, letters} from './foo';