export function getBreakfast() {};
export function getLunch() {};
export const baz = 'baz';
export const letters = ['a', 'b', 'c'];
export default function getDinner() {};