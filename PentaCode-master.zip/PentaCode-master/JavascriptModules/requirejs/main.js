define([
    "component/underscore",
    "component/jQuery",
    "component/tracker",
    "component/analytics",
    "component/dog"
], function(_, $, Tracker, Analytics, Dog) { 
    // Now I have access to these things! 
    console.log(_, $, Tracker, Analytics, Dog);
});