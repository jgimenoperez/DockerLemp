var $ = require('jquery');

$(function() {
    alert('works!');
})