module.exports = 'Greetings from greet.js';
