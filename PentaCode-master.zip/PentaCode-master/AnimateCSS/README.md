Instant Live Reload Server
===========

Start a live reload server locally instantly, without all these complicated build tools!

Instructions
------------
**You need NodeJS installed**

```
npm install -g live-server
cd myProjectFolder
live-server
```

then a browser window should automatically open and serving the contents of your folder!

